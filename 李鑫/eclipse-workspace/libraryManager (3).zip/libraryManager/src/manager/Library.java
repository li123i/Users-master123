package manager;

import javax.swing.*;

public class Library {

    public static void main(String[] args) {

        JFrame logFrame = new LoginFrame();
        logFrame.setVisible(true);

    }

}