package manager;

public class Student extends Users {

    Student(String userName) {
        super(userName);
    }

    public boolean brrowBook() {
        //TODO
        return true;
    }

    public boolean returnBook() {
        //TODO
        return true;
    }


}
